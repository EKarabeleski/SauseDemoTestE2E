package Pages;

import Utils.baseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class sauceDemo extends baseClass {
    public sauceDemo(WebDriver driver) {
        this.driver = driver; //konstruktor
    }

    public void Url() {
        driver.get("https://www.saucedemo.com/");
    }

    public void sendText(String id, String text) throws InterruptedException {
        driver.findElement(By.id(id)).sendKeys(text);
    }

    public void clickButton(String id) throws InterruptedException {
        driver.findElement(By.id(id)).click();
    }

    public void titleValidation() throws InterruptedException {
        driver.getTitle();

    }

    public void FindProduct(String xpath) throws InterruptedException {
        driver.findElement(By.xpath(xpath)).click();
    }

    public void GetPrice(String xpath) throws InterruptedException {
        driver.findElement(By.xpath(xpath)).getText();
    }

    public void addToCart(String id) throws InterruptedException {
        driver.findElement(By.id(id));
    }

    public static void printElements(String label, List<WebElement> elements) {
        for (WebElement element : elements) {
            System.out.println(label + element.getText());
        }
    }
}





