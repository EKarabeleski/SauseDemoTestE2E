package Tests;

public class sauceDemoCheckout {
}
